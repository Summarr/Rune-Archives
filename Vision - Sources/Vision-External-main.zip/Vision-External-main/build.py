import os

embedStr = "-----------EMBEDDED---------------\n"
headerList = []
ToEmbedPath = "ToEmbed"


folders = os.listdir(ToEmbedPath)


def readfile(path):
    file = open(path, "r")
    str = file.read()
    file.close()
    return str


def addModuleFolder(path):
    global embedStr
    objName = os.path.splitext(os.path.basename(path))[0]
    if os.path.isdir(path):
        embedStr += '["' + objName + '"] = {\n'
        list = os.listdir(path)
        for obj in list:
            addModuleFolder(path + "/" + obj)
        embedStr += "},\n"
    else:
        moduleSource = readfile(path)
        embedStr += '["' + objName + '"] = function()\n' + moduleSource + "\nend,\n"


for folder in folders:
    folderpath = ToEmbedPath + "/" + folder + "/"
    modules = os.listdir(folderpath)

    headerList.append(folder)

    embedStr += folder + " = {\n"

    for module in modules:
        addModuleFolder(folderpath + "/" + module)
    embedStr += "}\n"


embedStr += "-----------MAIN CODE--------------\n"
embedStr += readfile("main.luau")

with open("input.luau", "w") as file:
    file.write("local " + ",".join(headerList) + "\n" + embedStr)
