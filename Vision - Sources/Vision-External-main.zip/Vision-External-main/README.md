# Guide
1. Download [RC2] and update `input.luau` file in RC2 directory with our [input.luau]
2. Download our app [build] and make sure to install all python pip packages
3. Join a game (can be without tool)
4. Launch `byfronmoment.exe` [RC2]
5. Wait for Notification to pop up in the Roblox window (SetCore)
6. Launch `app.py` from the [build]
7. Go to Script Editor and click on the left-most button in its window (there's also run and clear buttons)
5. Wait for Notification to pop up in the Roblox window (SetCore)
6. You should be free to run any scripts

[RC2]: https://cdn.discordapp.com/attachments/1176245525406810293/1176513374327160852/Release.rar
[input.luau]: https://github.com/phoriah/exVision/blob/main/input.luau
[build]: https://cdn.discordapp.com/attachments/1192061524181794837/1192284340084822026/build.zip
